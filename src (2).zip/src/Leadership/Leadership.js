// import React from"react";import"./Leadership.css";
// const leaders=[{name:"Director Name",role:"Director — Strategy & Growth",bio:"Leads business direction, development strategy, partnerships and the long-term growth roadmap of Elevate Infra.",img:"https://images.unsplash.com/photo-1560250097-0b93528c311a?auto=format&fit=crop&w=1000&q=88"},{name:"Director Name",role:"Director — Projects & Operations",bio:"Leads project planning, execution coordination, quality systems and the operational discipline behind every development.",img:"https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&w=1000&q=88"}];
// export default function Leadership(){return <><section className="page-hero leadership-hero"><div className="container"><span className="eyebrow">Leadership</span><h1 className="page-title">Two leaders.<br/><span className="gold">One development vision.</span></h1><p>Strategy and execution come together through a shared commitment to thoughtful growth and responsible development.</p></div></section><section className="section leaders"><div className="container"><div className="leader-note">Replace the demo names, portraits and biographies below with the client's approved director information.</div><div className="leader-cards">{leaders.map((l,i)=><article className="leader-card" key={i}><div className="leader-img"><img src={l.img} alt="Leadership placeholder"/><span>0{i+1}</span></div><div className="leader-copy"><span className="eyebrow">{l.role}</span><h2>{l.name}</h2><p>{l.bio}</p></div></article>)}</div></div></section><section className="leadership-statement"><div className="container"><span className="eyebrow">Leadership Philosophy</span><h2>Think clearly. Execute responsibly. <span>Build for the long term.</span></h2></div></section></>}
import React from "react";
import { Link } from "react-router-dom";
import "./Leadership.css";

const leaders = [
  {
    id: "01",
    name: "Director Name",
    role: "Director — Strategy & Growth",
    shortRole: "Strategy & Growth",
    bio: "Leads business direction, development strategy, partnerships and the long-term growth roadmap of Elevate Infra.",
    image:
      "https://images.unsplash.com/photo-1560250097-0b93528c311a?auto=format&fit=crop&w=1400&q=90",
  },
  {
    id: "02",
    name: "Director Name",
    role: "Director — Projects & Operations",
    shortRole: "Projects & Operations",
    bio: "Leads project planning, execution coordination, quality systems and the operational discipline behind every development.",
    image:
      "https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&w=1400&q=90",
  },
];

const leadershipPrinciples = [
  {
    number: "01",
    title: "Clear Direction",
    text: "Every development begins with a clear understanding of the opportunity, the market and the people it is intended to serve.",
  },
  {
    number: "02",
    title: "Responsible Decisions",
    text: "We believe strong development is built through thoughtful decisions, transparent communication and disciplined execution.",
  },
  {
    number: "03",
    title: "Long-Term Thinking",
    text: "Our focus extends beyond delivery. We aim to create developments that remain relevant, useful and valuable over time.",
  },
];

export default function Leadership() {
  return (
    <>
      {/* =====================================================
          HERO
      ===================================================== */}
      <section className="page-hero leadership-hero">
        <div className="container leadership-hero-inner">
          <div className="leadership-hero-copy">
            <span className="eyebrow">Leadership</span>

            <h1 className="page-title">
              People behind
              <br />
              <span>the vision.</span>
            </h1>

            <p>
              Elevate Infra is driven by a leadership approach that brings
              strategic thinking, development discipline and a long-term
              perspective to every opportunity.
            </p>

            <div className="leadership-hero-line">
              <span></span>
              <small>STRATEGY • EXECUTION • VALUE CREATION</small>
            </div>
          </div>

          <div className="leadership-hero-side">
            <div className="hero-side-number">02</div>

            <div>
              <strong>Leadership</strong>
              <span>Directors shaping the next chapter of Elevate Infra</span>
            </div>
          </div>
        </div>
      </section>

      {/* =====================================================
          INTRO
      ===================================================== */}
      <section className="leadership-intro">
        <div className="container leadership-intro-grid">
          <div className="leadership-intro-title">
            <span className="eyebrow">The Leadership Team</span>

            <h2>
              Different strengths.
              <br />
              <span>One direction.</span>
            </h2>
          </div>

          <div className="leadership-intro-copy">
            <p>
              Strong real estate development requires more than a good idea.
              It requires the ability to understand opportunity, make
              decisions with clarity and bring multiple disciplines together.
            </p>

            <p>
              At Elevate Infra, leadership connects the larger development
              vision with the practical realities of planning, execution,
              partnerships and long-term value.
            </p>
          </div>
        </div>
      </section>

      {/* =====================================================
          LEADERS
      ===================================================== */}
      <section className="section leaders">
        <div className="container">
          <div className="leaders-heading">
            <div>
              <span className="eyebrow">Our Directors</span>

              <h2>
                Leadership with
                <span> purpose.</span>
              </h2>
            </div>

            <p>
              Two complementary leadership responsibilities working together
              across strategy, projects and business growth.
            </p>
          </div>

          <div className="leader-cards">
            {leaders.map((leader) => (
              <article className="leader-card" key={leader.id}>
                <div className="leader-image-wrap">
                  <img src={leader.image} alt={leader.name} />

                  <div className="leader-image-overlay"></div>

                  <span className="leader-number">{leader.id}</span>

                  <div className="leader-image-label">
                    <span>DIRECTOR</span>
                    <strong>{leader.shortRole}</strong>
                  </div>
                </div>

                <div className="leader-copy">
                  <div className="leader-role">{leader.role}</div>

                  <h3>{leader.name}</h3>

                  <div className="leader-divider"></div>

                  <p>{leader.bio}</p>

                  <div className="leader-footer">
                    <span>Elevate Infra</span>
                    <span>Leadership</span>
                  </div>
                </div>
              </article>
            ))}
          </div>

          <div className="leader-placeholder-note">
            <span>NOTE</span>
            <p>
              Director names, photographs and biographies can be replaced with
              the final approved leadership information.
            </p>
          </div>
        </div>
      </section>

      {/* =====================================================
          LEADERSHIP APPROACH
      ===================================================== */}
      <section className="leadership-approach">
        <div className="container">
          <div className="approach-top">
            <div>
              <span className="eyebrow">Leadership Approach</span>

              <h2>
                How we think about
                <span> building.</span>
              </h2>
            </div>

            <p>
              Development is a long journey. Our leadership philosophy is
              centred around making better decisions at every stage — from
              identifying an opportunity to creating lasting value.
            </p>
          </div>

          <div className="principles-grid">
            {leadershipPrinciples.map((item) => (
              <article className="principle-card" key={item.number}>
                <div className="principle-number">{item.number}</div>

                <div className="principle-content">
                  <h3>{item.title}</h3>
                  <p>{item.text}</p>
                </div>

                <span className="principle-arrow">↗</span>
              </article>
            ))}
          </div>
        </div>
      </section>

      {/* =====================================================
          LEADERSHIP QUOTE / CANVAS
      ===================================================== */}
      <section className="leadership-canvas">
        <div className="container">
          <div className="canvas-frame">
            <div className="canvas-accent"></div>

            <div className="canvas-content">
              <span className="eyebrow">A Shared Perspective</span>

              <h2>
                “Good development creates more than
                <span> buildings.</span>
                <br />
                It creates places with a future.”
              </h2>

              <div className="canvas-bottom">
                <span>01</span>

                <p>
                  Strategy gives direction. Execution gives it form. Together,
                  they create the foundation for enduring real estate value.
                </p>

                <span>2026</span>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* =====================================================
          CTA
      ===================================================== */}
      <section className="leadership-cta">
        <div className="container leadership-cta-inner">
          <div>
            <span className="eyebrow">Connect With Us</span>

            <h2>
              Have a development
              <span> opportunity?</span>
            </h2>

            <p>
              Let's start a conversation around the opportunity, its potential
              and the right development direction.
            </p>
          </div>

          <Link className="btn" to="/contact">
            Start a Conversation ↗
          </Link>
        </div>
      </section>
    </>
  );
}