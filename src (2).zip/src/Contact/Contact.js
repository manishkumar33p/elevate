// import React,{useState}from"react";import"./Contact.css";
// export default function Contact(){const[sent,setSent]=useState(false);const submit=e=>{e.preventDefault();setSent(true);e.currentTarget.reset()};return <><section className="page-hero contact-hero"><div className="container"><span className="eyebrow">Contact</span><h1 className="page-title">Let's discuss<br/><span className="gold">what's possible.</span></h1><p>For project enquiries, land opportunities, development partnerships or business conversations, connect with Elevate Infra.</p></div></section><section className="section contact-section"><div className="container contact-grid"><div className="contact-copy"><span className="eyebrow">Corporate Enquiries</span><h2 className="section-title">Start a <span>conversation.</span></h2><p>Contact information below is placeholder content. Replace it with the client's approved office address, phone and email before publishing.</p><div className="contact-detail"><small>Office</small><b>Corporate Office, Delhi NCR, India</b></div><div className="contact-detail"><small>Phone</small><b>+91 99999 99999</b></div><div className="contact-detail"><small>Email</small><b>info@elevateinfra.com</b></div><div className="contact-detail"><small>Business Hours</small><b>Mon — Sat · 10:00 AM — 6:30 PM</b></div></div><form className="contact-form" onSubmit={submit}><div className="form-row"><label>Full Name<input required name="name" placeholder="Your name"/></label><label>Phone Number<input required name="phone" placeholder="+91"/></label></div><label>Email Address<input type="email" name="email" placeholder="you@example.com"/></label><label>I'm interested in<select name="interest"><option>Project Enquiry</option><option>Land / Joint Development</option><option>Partnership</option><option>Investment / Business</option><option>Other</option></select></label><label>Message<textarea name="message" rows="6" placeholder="Tell us about your requirement..."/></label><button className="btn" type="submit">Send Enquiry ↗</button>{sent&&<p className="success">Thank you. This demo form has captured the submission on screen only.</p>}</form></div></section></>}
import React, { useState } from "react";
import "./Contact.css";

const WHATSAPP_NUMBER = "919958424916";

export default function Contact() {
  const [sent, setSent] = useState(false);

  const submit = (e) => {
    e.preventDefault();

    const form = e.currentTarget;
    const data = new FormData(form);

    const name = data.get("name")?.trim();
    const phone = data.get("phone")?.trim();
    const email = data.get("email")?.trim();
    const interest = data.get("interest");
    const message = data.get("message")?.trim();

    const whatsappMessage = `
Hello Elevate Infra,

I would like to make an enquiry.

Name: ${name}
Phone: ${phone}
Email: ${email || "Not provided"}

Interested In:
${interest}

Message:
${message || "No additional message"}

Thank you.
    `.trim();

    const whatsappUrl = `https://wa.me/${WHATSAPP_NUMBER}?text=${encodeURIComponent(
      whatsappMessage
    )}`;

    setSent(true);

    window.open(whatsappUrl, "_blank", "noopener,noreferrer");

    form.reset();
  };

  return (
    <>
      {/* =====================================================
          HERO
      ===================================================== */}
      <section className="page-hero contact-hero">
        <div className="container contact-hero-inner">
          <div>
            <span className="eyebrow">Contact Elevate Infra</span>

            <h1 className="page-title">
              Let's discuss
              <br />
              <span>what's possible.</span>
            </h1>

            <p>
              For project enquiries, land opportunities, development
              partnerships or business conversations, connect with Elevate
              Infra.
            </p>

            <div className="contact-hero-line">
              <span></span>
              <small>PROJECTS • PARTNERSHIPS • DEVELOPMENT</small>
            </div>
          </div>

          <div className="contact-hero-side">
            <strong>Let's Connect</strong>
            <span>Start a conversation with our team.</span>
          </div>
        </div>
      </section>

      {/* =====================================================
          CONTACT SECTION
      ===================================================== */}
      <section className="section contact-section">
        <div className="container">
          <div className="contact-grid">
            {/* LEFT */}
            <div className="contact-copy">
              <span className="eyebrow">Corporate Enquiries</span>

              <h2 className="section-title">
                Start a <span>conversation.</span>
              </h2>

              <p className="contact-description">
                Whether you are exploring a development opportunity, looking
                for a strategic partnership or simply want to understand more
                about Elevate Infra, we would be happy to hear from you.
              </p>

              <div className="contact-details">
                <div className="contact-detail">
                  <small>Office</small>
                  <b>Corporate Office, Delhi NCR, India</b>
                </div>

                <div className="contact-detail">
                  <small>WhatsApp / Phone</small>
                  <b>+91 99584 24916</b>
                </div>

                <div className="contact-detail">
                  <small>Email</small>
                  <b>info@elevateinfra.com</b>
                </div>

                <div className="contact-detail">
                  <small>Business Hours</small>
                  <b>Mon — Sat · 10:00 AM — 6:30 PM</b>
                </div>
              </div>

              <a
                className="contact-whatsapp"
                href="https://wa.me/919958424916"
                target="_blank"
                rel="noopener noreferrer"
              >
                <span className="whatsapp-icon">↗</span>

                <div>
                  <small>QUICK CONTACT</small>
                  <strong>Chat with us on WhatsApp</strong>
                </div>
              </a>
            </div>

            {/* RIGHT FORM */}
            <div className="contact-form-box">
              <div className="form-heading">
                <span>01</span>

                <div>
                  <h3>Send an enquiry</h3>
                  <p>
                    Fill in your details and our team will connect with you.
                  </p>
                </div>
              </div>

              <form className="contact-form" onSubmit={submit}>
                <div className="form-row">
                  <label>
                    Full Name
                    <input
                      required
                      name="name"
                      type="text"
                      placeholder="Your name"
                    />
                  </label>

                  <label>
                    Phone Number
                    <input
                      required
                      name="phone"
                      type="tel"
                      placeholder="+91"
                    />
                  </label>
                </div>

                <label>
                  Email Address
                  <input
                    type="email"
                    name="email"
                    placeholder="you@example.com"
                  />
                </label>

                <label>
                  I'm interested in
                  <select name="interest">
                    <option>Project Enquiry</option>
                    <option>Land / Joint Development</option>
                    <option>Partnership</option>
                    <option>Investment / Business</option>
                    <option>General Enquiry</option>
                    <option>Other</option>
                  </select>
                </label>

                <label>
                  Message
                  <textarea
                    name="message"
                    rows="6"
                    placeholder="Tell us about your requirement..."
                  ></textarea>
                </label>

                <button className="btn contact-submit" type="submit">
                  Send Enquiry on WhatsApp ↗
                </button>

                {sent && (
                  <p className="success">
                    Your enquiry is ready. WhatsApp has been opened with your
                    message.
                  </p>
                )}
              </form>
            </div>
          </div>
        </div>
      </section>

      {/* =====================================================
          DEVELOPMENT OPPORTUNITIES
      ===================================================== */}
      <section className="contact-opportunities">
        <div className="container">
          <div className="opportunities-heading">
            <div>
              <span className="eyebrow">What Can We Discuss?</span>

              <h2>
                Different opportunities.
                <span> One conversation.</span>
              </h2>
            </div>

            <p>
              We welcome conversations around development, land, partnerships
              and strategic opportunities.
            </p>
          </div>

          <div className="opportunity-grid">
            <article>
              <span>01</span>
              <h3>Land Opportunities</h3>
              <p>
                Explore potential development opportunities for suitable land
                parcels and locations.
              </p>
            </article>

            <article>
              <span>02</span>
              <h3>Joint Development</h3>
              <p>
                Discuss structured development partnerships with landowners
                and strategic partners.
              </p>
            </article>

            <article>
              <span>03</span>
              <h3>Project Enquiries</h3>
              <p>
                Connect with us to understand our developments, concepts and
                upcoming opportunities.
              </p>
            </article>

            <article>
              <span>04</span>
              <h3>Business Partnerships</h3>
              <p>
                Build strategic relationships across real estate and related
                development opportunities.
              </p>
            </article>
          </div>
        </div>
      </section>

      {/* =====================================================
          FINAL CTA
      ===================================================== */}
      <section className="contact-final">
        <div className="container">
          <span className="eyebrow">Elevate Infra</span>

          <h2>
            Every opportunity
            <span> starts with a conversation.</span>
          </h2>

          <a
            href="https://wa.me/919958424916"
            target="_blank"
            rel="noopener noreferrer"
            className="btn"
          >
            WhatsApp Us ↗
          </a>
        </div>
      </section>
    </>
  );
}