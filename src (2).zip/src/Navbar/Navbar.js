// import React,{useState} from "react";
// import {Link,NavLink} from "react-router-dom";
// import "./Navbar.css";
// export default function Navbar(){const[open,setOpen]=useState(false);const links=[["/","Home"],["/about","About"],["/expertise","Expertise"],["/projects","Developments"],["/leadership","Leadership"],["/gallery","Gallery"]];return <header className="navbar"><div className="container nav-inner"><Link className="brand" to="/" onClick={()=>setOpen(false)}><span className="brand-mark">E</span><span className="brand-copy"><b>ELEVATE</b><small>INFRA</small></span></Link><button className="menu-btn" aria-label="Menu" onClick={()=>setOpen(!open)}>{open?"×":"☰"}</button><nav className={open?"nav-links open":"nav-links"}>{links.map(([to,label])=><NavLink key={to} to={to} end={to==="/"} onClick={()=>setOpen(false)}>{label}</NavLink>)}<Link className="nav-cta" to="/contact" onClick={()=>setOpen(false)}>Enquire ↗</Link></nav></div></header>}
import React, { useState } from "react";
import { Link, NavLink } from "react-router-dom";
import "./Navbar.css";

export default function Navbar() {
  const [open, setOpen] = useState(false);

  const links = [
    ["/", "Home"],
    ["/about", "About"],
    ["/expertise", "Expertise"],
    ["/projects", "Developments"],
    ["/leadership", "Leadership"],
    ["/gallery", "Gallery"],
  ];

  return (
    <header className="navbar">
      <div className="container nav-inner">

        {/* BRAND */}
        <Link
          className="brand"
          to="/"
          onClick={() => setOpen(false)}
        >
          <span className="brand-mark">E</span>

          <span className="brand-copy">
            <b>ELEVATE</b>
            <small>INFRA</small>
          </span>
        </Link>

        {/* MOBILE MENU */}
        <button
          className="menu-btn"
          aria-label="Toggle navigation"
          onClick={() => setOpen(!open)}
        >
          {open ? "×" : "☰"}
        </button>

        {/* NAVIGATION */}
        <nav className={open ? "nav-links open" : "nav-links"}>
          {links.map(([to, label]) => (
            <NavLink
              key={to}
              to={to}
              end={to === "/"}
              onClick={() => setOpen(false)}
            >
              {label}
            </NavLink>
          ))}

          <Link
            className="nav-cta"
            to="/contact"
            onClick={() => setOpen(false)}
          >
            Enquire
            <span>↗</span>
          </Link>
        </nav>

      </div>
    </header>
  );
}