// import React from"react";import{Link}from"react-router-dom";import"./Expertise.css";
// const items=[["01","Development Strategy","Site understanding, feasibility, product positioning and a clear roadmap before execution begins."],["02","Residential Development","Communities planned around liveability, efficient layouts, amenities and long-term value."],["03","Commercial Development","Workplaces and business destinations designed for identity, performance and connectivity."],["04","Planning & Design","Coordination of architecture, engineering, landscape and user experience around one vision."],["05","Project Execution","Structured procurement, construction coordination, quality review and delivery discipline."],["06","Partnership & Value Creation","Collaborative development models for landowners, investors and strategic partners."]];
// export default function Expertise(){return <><section className="page-hero expertise-hero"><div className="container"><span className="eyebrow">Our Expertise</span><h1 className="page-title">One development journey.<br/><span className="gold">Connected end to end.</span></h1><p>Our role is to connect strategy, design, execution and commercial thinking so every project moves with clarity.</p></div></section><section className="section expertise-list"><div className="container"><div className="section-head"><div><span className="eyebrow">What We Do</span><h2 className="section-title">Capability across the <span>development lifecycle.</span></h2></div></div><div className="expertise-grid">{items.map(x=><article key={x[0]}><b>{x[0]}</b><h3>{x[1]}</h3><p>{x[2]}</p></article>)}</div></div></section><section className="expertise-banner"><div className="container expertise-banner-copy"><span className="eyebrow">Integrated Thinking</span><h2>Better coordination creates <span>better real estate.</span></h2><p>By treating each discipline as part of one development system, we aim to reduce friction, improve decisions and protect the project's long-term value.</p><Link className="btn" to="/projects">Explore Developments ↗</Link></div></section></>}
import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import "./Expertise.css";

const items = [
  {
    no: "01",
    title: "Development Strategy",
    text:
      "Understanding site potential, feasibility, market context and product positioning before development begins.",
  },
  {
    no: "02",
    title: "Residential Development",
    text:
      "Creating thoughtfully planned communities around liveability, efficient layouts, amenities and long-term relevance.",
  },
  {
    no: "03",
    title: "Commercial Development",
    text:
      "Developing contemporary business environments focused on accessibility, performance, identity and user experience.",
  },
  {
    no: "04",
    title: "Planning & Design",
    text:
      "Coordinating architecture, engineering, landscape and functionality around one clear development vision.",
  },
  {
    no: "05",
    title: "Project Execution",
    text:
      "Structured coordination, procurement, quality review and execution discipline from planning through delivery.",
  },
  {
    no: "06",
    title: "Partnership & Value Creation",
    text:
      "Exploring collaborative development opportunities with landowners, investors and strategic partners.",
  },
];

const process = [
  {
    no: "01",
    title: "Discover",
    text:
      "We begin by understanding the site, location, connectivity, opportunity and surrounding market.",
  },
  {
    no: "02",
    title: "Strategise",
    text:
      "Development potential is translated into a clear product, positioning and commercial strategy.",
  },
  {
    no: "03",
    title: "Design",
    text:
      "Architecture, engineering, landscape and experience are coordinated around one vision.",
  },
  {
    no: "04",
    title: "Execute",
    text:
      "Structured processes and quality controls help translate planning into built reality.",
  },
  {
    no: "05",
    title: "Deliver",
    text:
      "The final focus is on creating a development that performs for users, partners and its location.",
  },
];

const carousel = [
  {
    tag: "Residential Development",
    title: "Creating places designed around everyday life.",
    text:
      "Our residential approach focuses on thoughtful planning, usable spaces, connectivity, landscape and the details that shape everyday living.",
    image:
      "https://images.unsplash.com/photo-1600607687939-ce8a6c25118c?auto=format&fit=crop&w=1600&q=88",
  },
  {
    tag: "Commercial Development",
    title: "Business environments built for performance.",
    text:
      "Commercial development requires the right balance of visibility, accessibility, efficiency, architecture and long-term adaptability.",
    image:
      "https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?auto=format&fit=crop&w=1600&q=88",
  },
  {
    tag: "Planning & Design",
    title: "Good development starts with better decisions.",
    text:
      "Before construction begins, planning decisions establish how a development will function, feel and continue to create value over time.",
    image:
      "https://images.unsplash.com/photo-1600585154340-be6161a56a0c?auto=format&fit=crop&w=1600&q=88",
  },
  {
    tag: "Development Partnerships",
    title: "Unlocking potential through collaboration.",
    text:
      "We aim to create aligned partnerships where land potential, development expertise and long-term commercial thinking work together.",
    image:
      "https://images.unsplash.com/photo-1497366811353-6870744d04b2?auto=format&fit=crop&w=1600&q=88",
  },
];

const principles = [
  {
    no: "01",
    title: "Clarity",
    text:
      "Clear objectives and informed decisions before major commitments are made.",
  },
  {
    no: "02",
    title: "Coordination",
    text:
      "Bringing multiple disciplines together instead of treating them as disconnected activities.",
  },
  {
    no: "03",
    title: "Quality",
    text:
      "Attention to planning, materials, detailing and execution throughout the development process.",
  },
  {
    no: "04",
    title: "Value",
    text:
      "Balancing experience, efficiency and commercial thinking with a long-term perspective.",
  },
];

export default function Expertise() {
  const [activeSlide, setActiveSlide] = useState(0);

  useEffect(() => {
    const timer = setInterval(() => {
      setActiveSlide((prev) => (prev + 1) % carousel.length);
    }, 5000);

    return () => clearInterval(timer);
  }, []);

  const nextSlide = () => {
    setActiveSlide((prev) => (prev + 1) % carousel.length);
  };

  const prevSlide = () => {
    setActiveSlide(
      (prev) => (prev - 1 + carousel.length) % carousel.length
    );
  };

  return (
    <>
      {/* =====================================================
          HERO
      ===================================================== */}

      <section className="page-hero expertise-hero">
        <div className="container expertise-hero-content">
          <span className="eyebrow">Our Expertise</span>

          <h1 className="page-title">
            One development journey.
            <br />
            <span>Connected end to end.</span>
          </h1>

          <p>
            We connect strategy, planning, design, execution and
            commercial thinking to create a more coordinated
            approach to real estate development.
          </p>

          <div className="expertise-hero-actions">
            <Link className="btn" to="/projects">
              Explore Developments ↗
            </Link>

            <Link
              className="btn expertise-outline-btn"
              to="/contact"
            >
              Discuss an Opportunity
            </Link>
          </div>
        </div>
      </section>

      {/* =====================================================
          INTRO
      ===================================================== */}

      <section className="expertise-intro">
        <div className="container expertise-intro-grid">
          <div>
            <span className="eyebrow">Integrated Expertise</span>

            <h2>
              Development works better when
              <span> everything works together.</span>
            </h2>
          </div>

          <div className="expertise-intro-copy">
            <p>
              Real estate development involves far more than
              construction. Every successful project is shaped by
              decisions around land, feasibility, positioning,
              planning, architecture, engineering, execution and
              commercial strategy.
            </p>

            <p>
              Our approach is to connect these disciplines rather
              than treat them as isolated stages. This creates
              greater clarity, stronger coordination and a more
              consistent development vision.
            </p>

            <Link className="expertise-text-link" to="/about">
              Learn about Elevate Infra →
            </Link>
          </div>
        </div>
      </section>

      {/* =====================================================
          SMALL STRIP
      ===================================================== */}

      <section className="expertise-strip">
        <div className="container expertise-strip-grid">
          <div>
            <strong>Strategy</strong>
            <span>Understanding the opportunity</span>
          </div>

          <div>
            <strong>Planning</strong>
            <span>Creating the development framework</span>
          </div>

          <div>
            <strong>Execution</strong>
            <span>Translating vision into reality</span>
          </div>

          <div>
            <strong>Value</strong>
            <span>Thinking beyond project delivery</span>
          </div>
        </div>
      </section>

      {/* =====================================================
          CAPABILITIES
      ===================================================== */}

      <section className="expertise-list">
        <div className="container">
          <div className="expertise-section-head">
            <div>
              <span className="eyebrow">What We Do</span>

              <h2>
                Capability across the
                <span> development lifecycle.</span>
              </h2>
            </div>

            <p>
              Our capabilities cover the key stages required to
              take an opportunity from initial thinking to a
              coordinated real estate development.
            </p>
          </div>

          <div className="expertise-grid">
            {items.map((item) => (
              <article key={item.no}>
                <b>{item.no}</b>

                <h3>{item.title}</h3>

                <p>{item.text}</p>

                <span className="expertise-card-arrow">↗</span>
              </article>
            ))}
          </div>
        </div>
      </section>

      {/* =====================================================
          CAROUSEL
      ===================================================== */}

      <section className="expertise-carousel">
        <div className="expertise-carousel-stage">
          {carousel.map((slide, index) => (
            <div
              key={index}
              className={`expertise-carousel-slide ${
                index === activeSlide ? "active" : ""
              }`}
            >
              <img src={slide.image} alt={slide.tag} />

              <div className="expertise-carousel-overlay" />

              <div className="container expertise-carousel-content">
                <span className="eyebrow">{slide.tag}</span>

                <h2>{slide.title}</h2>

                <p>{slide.text}</p>

                <Link className="btn" to="/contact">
                  Start a Conversation ↗
                </Link>
              </div>
            </div>
          ))}

          <div className="expertise-carousel-controls">
            <button
              onClick={prevSlide}
              aria-label="Previous slide"
            >
              ←
            </button>

            <div className="expertise-carousel-dots">
              {carousel.map((_, index) => (
                <button
                  key={index}
                  className={
                    activeSlide === index ? "active" : ""
                  }
                  onClick={() => setActiveSlide(index)}
                  aria-label={`Slide ${index + 1}`}
                />
              ))}
            </div>

            <button
              onClick={nextSlide}
              aria-label="Next slide"
            >
              →
            </button>
          </div>

          <div className="expertise-slide-count">
            0{activeSlide + 1}
            <span>/ 0{carousel.length}</span>
          </div>
        </div>
      </section>

      {/* =====================================================
          PROCESS
      ===================================================== */}

      <section className="expertise-process">
        <div className="container">
          <div className="expertise-section-head">
            <div>
              <span className="eyebrow">Our Process</span>

              <h2>
                From opportunity to
                <span> built reality.</span>
              </h2>
            </div>

            <p>
              Our process creates a clear path through the
              complexity of development while keeping the
              original vision connected to execution.
            </p>
          </div>

          <div className="expertise-process-grid">
            {process.map((item) => (
              <div className="process-card" key={item.no}>
                <span>{item.no}</span>

                <h3>{item.title}</h3>

                <p>{item.text}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* =====================================================
          IMAGE + THINKING
      ===================================================== */}

      <section className="expertise-thinking">
        <div className="container expertise-thinking-grid">
          <div className="expertise-thinking-images">
            <img
              className="thinking-main-image"
              src="https://images.unsplash.com/photo-1600566753086-00f18fb6b3ea?auto=format&fit=crop&w=1100&q=88"
              alt="Modern architecture"
            />

            <div className="thinking-small-box">
              <strong>360°</strong>
              <span>
                Integrated development thinking
              </span>
            </div>
          </div>

          <div className="expertise-thinking-copy">
            <span className="eyebrow">
              Integrated Thinking
            </span>

            <h2>
              Better coordination creates
              <span> better real estate.</span>
            </h2>

            <p>
              A project may involve architects, engineers,
              consultants, contractors, financial stakeholders
              and multiple operational teams. The quality of the
              final development depends on how effectively these
              disciplines work together.
            </p>

            <p>
              Our development approach focuses on maintaining
              clarity between these moving parts so that
              important decisions remain connected to the
              project's broader objectives.
            </p>

            <Link className="btn" to="/projects">
              Explore Developments ↗
            </Link>
          </div>
        </div>
      </section>

      {/* =====================================================
          PRINCIPLES
      ===================================================== */}

      <section className="expertise-principles">
        <div className="container">
          <div className="expertise-section-head">
            <div>
              <span className="eyebrow">
                How We Work
              </span>

              <h2>
                Four principles.
                <span> One development mindset.</span>
              </h2>
            </div>
          </div>

          <div className="expertise-principles-grid">
            {principles.map((item) => (
              <article key={item.no}>
                <span>{item.no}</span>

                <h3>{item.title}</h3>

                <p>{item.text}</p>
              </article>
            ))}
          </div>
        </div>
      </section>

      {/* =====================================================
          PARTNERSHIP
      ===================================================== */}

      <section className="expertise-partnership">
        <div className="container expertise-partnership-grid">
          <div>
            <span className="eyebrow">
              Development Partnerships
            </span>

            <h2>
              Unlocking potential
              <span> together.</span>
            </h2>
          </div>

          <div>
            <p>
              Some of the strongest development opportunities
              begin with the right partnership. We are open to
              exploring opportunities with landowners, investors
              and strategic partners where our development
              capabilities can create shared value.
            </p>

            <p>
              Our objective is to approach each opportunity with
              clear commercial thinking, transparent
              communication and a long-term perspective.
            </p>

            <Link className="btn" to="/contact">
              Discuss a Partnership ↗
            </Link>
          </div>
        </div>
      </section>

      {/* =====================================================
          FINAL CTA
      ===================================================== */}

      <section className="expertise-final-cta">
        <div className="container">
          <span className="eyebrow">
            Elevate Infra
          </span>

          <h2>
            Have a development
            <span> opportunity in mind?</span>
          </h2>

          <p>
            Connect with us to discuss land, development,
            collaboration or strategic real estate opportunities.
          </p>

          <div className="expertise-cta-actions">
            <Link className="btn" to="/contact">
              Start a Conversation ↗
            </Link>

            <Link
              className="btn expertise-final-outline"
              to="/projects"
            >
              View Developments
            </Link>
          </div>
        </div>
      </section>
    </>
  );
}