// import React from "react";
// import {
//   BrowserRouter,
//   Routes,
//   Route,
// } from "react-router-dom";

// import Home from "../Home/Home";
// import About from "../About/About";
// import Projects from "../Projects/Projects";
// import ProjectDetails from "../ProjectDetails/ProjectDetails";
// import Leadership from "../Leadership/Leadership";
// import Expertise from "../Expertise/Expertise";
// import Gallery from "../Gallery/Gallery";
// import Contact from "../Contact/Contact";

// function App() {
//   return (
//     <BrowserRouter>
//       <Routes>
//         <Route path="/" element={<Home />} />

//         <Route path="/about" element={<About />} />

//         <Route path="/expertise" element={<Expertise />} />

//         <Route path="/projects" element={<Projects />} />

//         <Route
//           path="/projects/:id"
//           element={<ProjectDetails />}
//         />

//         <Route path="/leadership" element={<Leadership />} />

//         <Route path="/gallery" element={<Gallery />} />

//         <Route path="/contact" element={<Contact />} />

//         <Route
//           path="*"
//           element={<Home />}
//         />
//       </Routes>
//     </BrowserRouter>
//   );
// }

// export default App;


import React from "react";
import {
  BrowserRouter,
  Routes,
  Route,
} from "react-router-dom";

import Home from "./Home/Home";
import About from "./About/About";
import Projects from "./Projects/Projects";
import ProjectDetails from "./ProjectDetails/ProjectDetails";
import Leadership from "./Leadership/Leadership";
import Expertise from "./Expertise/Expertise";
import Gallery from "./Gallery/Gallery";
import Contact from "./Contact/Contact";
import Navbar from "./Navbar/Navbar";

function App() {
  return (
    <BrowserRouter>
    <Navbar></Navbar>
      <Routes>
        <Route path="/" element={<Home />} />

        <Route path="/about" element={<About />} />

        <Route path="/expertise" element={<Expertise />} />

        <Route path="/projects" element={<Projects />} />

        <Route
          path="/projects/:id"
          element={<ProjectDetails />}
        />

        <Route
          path="/leadership"
          element={<Leadership />}
        />

        <Route
          path="/gallery"
          element={<Gallery />}
        />

        <Route
          path="/contact"
          element={<Contact />}
        />

        <Route path="*" element={<Home />} />
      </Routes>
    </BrowserRouter>
  );
}

export default App;