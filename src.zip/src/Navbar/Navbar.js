import React,{useState} from 'react';
import {Link,NavLink} from 'react-router-dom';
import './Navbar.css';

export default function Navbar(){
 const [open,setOpen]=useState(false);
 const links=[['/','Home'],['/about','About'],['/expertise','Expertise'],['/projects','Projects'],['/leadership','Leadership'],['/gallery','Gallery']];
 return <header className="navbar"><div className="nav-inner container"><Link to="/" className="brand" onClick={()=>setOpen(false)}><span>ELEVATE</span><small>INFRA</small></Link><button className="menu-btn" onClick={()=>setOpen(!open)}>{open?'✕':'☰'}</button><nav className={open?'nav-links open':'nav-links'}>{links.map(([to,label])=><NavLink key={to} to={to} end={to==='/'} onClick={()=>setOpen(false)}>{label}</NavLink>)}<Link className="nav-cta" to="/contact" onClick={()=>setOpen(false)}>Enquire <span>↗</span></Link></nav></div></header>
}
