import React from "react";
import { Link, useParams } from "react-router-dom";
import { projects } from "../Projects/Projects";
import "./ProjectDetails.css";

export default function ProjectDetails() {
  const { id } = useParams();

  const p =
    projects.find((x) => x.id === id) || projects[0];

  return (
    <>
      {/* HERO */}
      <section
        className="detail-hero"
        style={{
          backgroundImage: `
            linear-gradient(
              90deg,
              rgba(5,10,8,.86),
              rgba(5,10,8,.25)
            ),
            url(${p.img})
          `,
        }}
      >
        <div className="container">
          <span className="eyebrow">{p.type}</span>

          <h1>{p.title}</h1>

          <p>{p.location}</p>
        </div>
      </section>

      {/* DEVELOPMENT DETAILS */}
      <section className="section detail-main">
        <div className="container detail-grid">

          <div>
            <span className="eyebrow">
              The Development
            </span>

            <h2>
              Designed for the way{" "}
              <span>life moves.</span>
            </h2>

            <p>{p.desc}</p>

            <p>
              {p.title} represents Elevate Infra's
              approach to development — strong planning,
              considered architecture, efficient
              infrastructure and a clear focus on
              long-term value.
            </p>
          </div>

          <div className="detail-facts">

            <div>
              <span>Status</span>
              <b>{p.status}</b>
            </div>

            <div>
              <span>Development Type</span>
              <b>{p.type}</b>
            </div>

            <div>
              <span>Location</span>
              <b>{p.location}</b>
            </div>

            <div>
              <span>Planned Area</span>
              <b>{p.area}</b>
            </div>

          </div>
        </div>
      </section>

      {/* GALLERY */}
      <section className="section detail-gallery">
        <div className="container">

          <div className="section-head">
            <div>
              <span className="eyebrow">
                Visual Direction
              </span>

              <h2>
                A glimpse of the{" "}
                <span>experience.</span>
              </h2>
            </div>
          </div>

          <div className="detail-images">

            <img
              src={p.img}
              alt={p.title}
            />

            <img
              src="https://images.unsplash.com/photo-1600585154526-990dced4db0d?auto=format&fit=crop&w=1100&q=85"
              alt="Interior"
            />

            <img
              src="https://images.unsplash.com/photo-1600607688969-a5bfcd646154?auto=format&fit=crop&w=1100&q=85"
              alt="Living space"
            />

          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="detail-cta">
        <div className="container">

          <h2>
            Want to know more about {p.title}?
          </h2>

          <Link
            className="btn"
            to="/contact"
          >
            Send an Enquiry ↗
          </Link>

        </div>
      </section>
    </>
  );
}